"""
WeiGPS init
"""
__all__ = [
    "weigps",
]

from .weigps import WeiGPS, WeiNoF

