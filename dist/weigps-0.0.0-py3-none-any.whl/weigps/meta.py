__all__ = [
    "__project__",
    "__title__",
    "__author__",
    "__copyright__",
    "__license__",
    "__version__",
    "__mail__",
    "__maintainer__",
    "__status__",
]

__project__ = "WeiGPS"
__title__ = "weigps"
__author__ = "Wei Liu"
__copyright__ = "Copyright 2024, Wei Liu"
__license__ = "MIT"
__version__ = "0.0.0"
__mail__ = "wordwaymusic@163.com"
__maintainer__ = __author__
__status__ = "Stable"
